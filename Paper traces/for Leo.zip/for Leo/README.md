proof{i}.md is the proof of conj{i}.txt

only the newest iteration have the traces, it solved conj18,19,22, so you can only find the traces for these conjectures.

in each log folder, you will find conj{i}_1.log, which has length of proof and length of feedback for each iteration

for each iteration i, you can find the detailed proof + detailed feedback from the judge in Iteration{i}.log